Please place the White assemblies in this folder.

The following acceptance test solution files depends on White assemblies.

StockTrader RI
=====================
{Application directory}\Source\StockTraderRI\StockTraderRI_AcceptanceTests.sln

QuickStarts
======================
{Application directory}\Source\QuickStarts\Commanding\Commanding_AcceptanceTests.sln
{Application directory}\Source\QuickStarts\EventAggregation\EventAggregation_AcceptanceTests.sln
{Application directory}\Source\QuickStarts\Modularity\Modularity_AcceptanceTests.sln
{Application directory}\Source\QuickStarts\UIComposition\UIComposition_AcceptanceTests.sln

