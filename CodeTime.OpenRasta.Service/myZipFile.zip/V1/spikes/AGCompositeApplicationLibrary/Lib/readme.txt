This folder needs to contain the following assemblies

Unity/Object Builder:
Microsoft.Practices.ObjectBuilder2.dll
Microsoft.Practices.Unity.dll


Silverlight Unit Testing (http://www.jeff.wilcox.name/2008/03/31/silverlight2-unit-testing/)
Microsoft.Silverlight.Testing.dll
Microsoft.Silverlight.Testing.Framework.dll
Microsoft.VisualStudio.QualityTools.UnitTesting.Silverlight.dll




